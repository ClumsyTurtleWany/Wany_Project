Control Key
Up: move cursor to above menu.
Down: move cursor to under menu.
Left: move cursor to page control.
Right: move cursor to page control or main menu.
Enter: select menu.
Esc: escape sub menu or escape program.