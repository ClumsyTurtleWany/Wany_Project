#pragma once
#include <thread>
#include <conio.h>
#include <cstdlib>
#include <ctime>
#include "UI.h"
#include <fstream>