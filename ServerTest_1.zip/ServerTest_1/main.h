#pragma once

#define _WINSOCK_DEPRECATED_NO_WARNINGS

#include <iostream>

#pragma comment(lib, "Ws2_32.lib") 

#include <WinSock2.h>
#include <WS2tcpip.h>

#include "ChatServer.h"
